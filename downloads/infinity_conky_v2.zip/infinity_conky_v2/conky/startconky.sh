#! /bin/bash
sleep 20
conky -c ~/.conkyrc